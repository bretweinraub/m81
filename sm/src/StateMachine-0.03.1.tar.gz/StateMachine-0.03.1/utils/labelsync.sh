#!/bin/sh
p4 sync ...@$SYNCLABEL
